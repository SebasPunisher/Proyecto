package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainClient extends AppCompatActivity {
Button btn_mujer, btn_hombre, btn_kid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_client);
        btn_mujer = findViewById(R.id.Btn_female);
        btn_hombre = findViewById(R.id.btn_Male);
        btn_kid= findViewById(R.id.btn_Kids);

        btn_mujer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ven = new Intent(MainClient.this,WomenClothes.class);
                startActivity(ven);
            }
        });

        btn_hombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               //Intent Mal = new Intent(MainClient.this,);
            }
        });

        btn_kid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}