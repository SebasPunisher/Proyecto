package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class WomenClothes extends AppCompatActivity {
EditText et_busca;
ImageButton btn_img_busca;
ListView lv_productos;
ConexionBD conectar2;
Button btn_Carrito, btn_Back, btn_Buy;
ArrayList datos;
String busqueda;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_women_clothes);
        et_busca=findViewById(R.id.et_search);
        btn_img_busca=findViewById(R.id.btnimg_search);
        lv_productos=findViewById(R.id.lv_productos);

        conectar2 = new ConexionBD();
        datos = new ArrayList();

        ConsultarProductos consultatodo=new ConsultarProductos();
        consultatodo.execute("Select nombre from productos","todo");
        btn_img_busca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                busqueda=et_busca.getText().toString()+"%";
                ConsultarProductos consultatodo=new ConsultarProductos();
                consultatodo.execute("Select nombre from productos where nombre like ?","nom");

            }
        });

        et_busca.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                return false;
            }
        });
    }//Cierre en el OnCreate
    public void LlenaProductos(ArrayList datos){
        ArrayAdapter adaptador = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_expandable_list_item_1,datos);
        lv_productos.setAdapter(adaptador);
    }//Cierre

   public class ConsultarProductos extends AsyncTask<String,String,String>{
        String message="";
        boolean exito=false;

       @Override
       protected void onPreExecute() {

       }

       @Override
       protected void onPostExecute(String msj) {
           if(exito){
               LlenaProductos(datos);
           }else{
               datos.clear();
               LlenaProductos(datos);

               Toast.makeText(getApplicationContext(),msj,Toast.LENGTH_SHORT).show();
           }
       }

       @Override
       public String doInBackground(String... strings) {
           Connection con= conectar2.Conectar();
           if(con!=null){

               try {
                   PreparedStatement ps=con.prepareStatement(strings[0]);
                   if (strings[1].equals("nom"));{
                       ps.setString(1,busqueda);
                   }

                   ResultSet rs = ps.executeQuery();

                   if (rs.next()){
                    datos.clear();
                    exito = true;
                    do {
                       datos.add(rs.getString("Nombre"));
                    }while(rs.next());
                   }else{
                       message="Sin Productos";
                   }
               } catch (SQLException e) {
                   e.printStackTrace();
               }

               try {
                   con.close();
               } catch (SQLException e) {
                   e.printStackTrace();
               }

           }else{
             message="No se puede conectar";
           }
           return message;
       }
   }
}