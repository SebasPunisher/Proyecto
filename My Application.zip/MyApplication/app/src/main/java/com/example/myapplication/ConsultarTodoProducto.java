package com.example.myapplication;

public interface ConsultarTodoProducto {
    void onPreExecute();

    void onPostExecute(String message);
}
