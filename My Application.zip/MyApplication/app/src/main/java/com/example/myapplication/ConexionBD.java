package com.example.myapplication;

import android.os.StrictMode;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionBD {
    private String ip="192.168.100.10:3306";
    private String bd="elegance";
    private String usuarioBD="Admistrador";
    private String passBD="CSPR24020609";
    private String url="jdbc:mysql://" + ip +"/"+ bd;

    public Connection Conectar(){
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
         Connection con=null;

         try {
             Class.forName("com.mysql.jdbc.Driver").newInstance();
             con =DriverManager.getConnection(url, usuarioBD, passBD);
         } catch (ClassNotFoundException e) {
             e.printStackTrace();
         } catch(Exception e){

         }
          return con;

    }//Fin de la conexión
}//Fin de la clase conexión
