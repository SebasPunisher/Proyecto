package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {
    EditText etUser, etPass;
    Button btnStart;
    ProgressBar pbInicio;
    ConexionBD conectar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etUser = findViewById(R.id.et_User);
        etPass = findViewById(R.id.et_Pass);
        btnStart = findViewById(R.id.btn_Iniciar);
        pbInicio=findViewById(R.id.pb_Iniciar);
        conectar =new ConexionBD();

        pbInicio.setVisibility(View.GONE);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InicioSesion inicio = new InicioSesion();
                inicio.execute("");
                Intent ver = new Intent(MainActivity.this,MainClient.class);
                startActivity(ver);
            }
        });
    }//Oncreate 1

    public class InicioSesion extends AsyncTask<String, String, String>{
      String mensaje;
      boolean exito = false;
      String email = etUser.getText().toString();
      String password = etUser.getText().toString();
        @Override
        protected void onPreExecute(){
            pbInicio.setVisibility(View.VISIBLE);

        }//Pre-Ejecucion

        @Override
        protected void onPostExecute(String msj){
            pbInicio.setVisibility(View.GONE);
            Toast.makeText(getApplicationContext(),msj,Toast.LENGTH_SHORT).show();

        }//Post-Ejecucion

        @Override
        protected String doInBackground(String... strings) {
            //Abrir la Conexión
            Connection con = conectar.Conectar();
            if (con!=null){//Instruccion a la BD
                String query = "Select * from usuario where email=? and password=?";

                try {
                    PreparedStatement ps = con.prepareStatement(query);
                    ps.setString(1,email);
                    ps.setString(2,password);
                    //Ejecutar la instrucción
                    ResultSet rs=ps.executeQuery();

                    //ResultSet rs =ps.executeQuery(query);

                    if(rs.next()){
                        exito=true;
                        mensaje="Bienvenido "+rs.getString("nombre");
                    }else{
                     mensaje = "Usuario o contraseña incorrecta";
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                //Cierre de la Conexión
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }else {
                mensaje="Error al conectar con la base de Datos";
            }
            return mensaje;
        }
    }//Fin de la sub-clase


}//fin de la clase